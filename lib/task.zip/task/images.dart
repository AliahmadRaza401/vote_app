class AppImages {
  static const one = "assets/pic/1.png";
  static const two = "assets/pic/2.png";
  static const tree = "assets/pic/3.png";
  static const four = "assets/pic/4.png";
  static const five = "assets/pic/5.png";
}

List<String> imageLiust = [
  "assets/pic/1.png",
  "assets/pic/2.png",
  "assets/pic/3.png",
  "assets/pic/4.png",
  "assets/pic/5.png",
  "assets/pic/1.png",
  "assets/pic/2.png",
  "assets/pic/3.png",
  "assets/pic/4.png",
  "assets/pic/5.png",
];
